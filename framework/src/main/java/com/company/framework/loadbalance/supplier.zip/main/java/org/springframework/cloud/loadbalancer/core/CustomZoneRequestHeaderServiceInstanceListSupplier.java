/*
 * Copyright 2012-2023 the original author or authors.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      https://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package org.springframework.cloud.loadbalancer.core;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Map;

import org.springframework.cloud.client.loadbalancer.RequestData;
import org.springframework.cloud.client.loadbalancer.RequestDataContext;
import org.springframework.http.HttpHeaders;
import org.springframework.util.StringUtils;
import reactor.core.publisher.Flux;

import org.springframework.cloud.client.ServiceInstance;
import org.springframework.cloud.client.loadbalancer.Request;
import org.springframework.cloud.client.loadbalancer.reactive.ReactiveLoadBalancer;

/**
 * 参考ZonePreferenceServiceInstanceListSupplier实现
 *
 * @author candi.jiang
 */
public class CustomZoneRequestHeaderServiceInstanceListSupplier extends DelegatingServiceInstanceListSupplier {

	private final String ZONE = "zone";

	public CustomZoneRequestHeaderServiceInstanceListSupplier(ServiceInstanceListSupplier delegate) {
		super(delegate);
	}

	public CustomZoneRequestHeaderServiceInstanceListSupplier(ServiceInstanceListSupplier delegate,
															  ReactiveLoadBalancer.Factory<ServiceInstance> loadBalancerClientFactory) {
		super(delegate);
	}

	@Override
	public Flux<List<ServiceInstance>> get() {
		return getDelegate().get();
	}

	@Override
	public Flux<List<ServiceInstance>> get(Request request) {
		Object context = request.getContext();
		RequestData requestData = ((RequestDataContext) context).getClientRequest();
		HttpHeaders headers = requestData.getHeaders();
		List<String> headerValues = headers.get(ZONE);

		String zoneValue;
		if (headerValues != null && !headerValues.isEmpty()) {
			zoneValue = headerValues.get(headerValues.size() - 1);// 取最后一个值
		} else {
			zoneValue = null;
		}
		if (!StringUtils.hasText(zoneValue)) {// 请求头 未指定zone，则返回所有服务列表
			return getDelegate().get(request);
		}
		return getDelegate().get(request).map(v -> filteredByZone(zoneValue, v));
	}

	private List<ServiceInstance> filteredByZone(String zone, List<ServiceInstance> serviceInstances) {
		if (zone != null) {
			List<ServiceInstance> filteredInstances = new ArrayList<>();
			for (ServiceInstance serviceInstance : serviceInstances) {
				String instanceZone = getZone(serviceInstance);
				if (zone.equalsIgnoreCase(instanceZone)) {
					filteredInstances.add(serviceInstance);
				}
			}
			if (filteredInstances.size() > 0) {
				return filteredInstances;
			}

			// 同zone没有找到实例，寻找没有配置zone的实例，适配原来没有配置zone的情况
			for (ServiceInstance serviceInstance : serviceInstances) {
				String instanceZone = getZone(serviceInstance);
				if (!StringUtils.hasText(instanceZone)) {
					filteredInstances.add(serviceInstance);
				}
			}
			return filteredInstances;
		}
		// If the zone is not set or there are no zone-specific instances available,
		// we return all instances retrieved for given service id.
		return serviceInstances;
	}

	private String getZone(ServiceInstance serviceInstance) {
		Map<String, String> metadata = serviceInstance.getMetadata();
		if (metadata != null) {
			return metadata.get(ZONE);
		}
		return null;
	}

}
