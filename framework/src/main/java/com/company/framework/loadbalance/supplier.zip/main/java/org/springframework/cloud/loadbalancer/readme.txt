这些代码都是复制org.springframework.cloud.loadbalancer包的源码，统一加了前缀Custom

一、改动点：
1.CustomLoadBalancerClientConfiguration编译问题
将@ConditionalOnClass(RetryTemplate.class)修改为@ConditionalOnClass(name = "org.springframework.retry.support.RetryTemplate")

2.CustomZonePreferenceServiceInstanceListSupplier
修改filteredByZone的逻辑，在‘if (filteredInstances.size() > 0) {’下增加以下逻辑
// 同zone没有找到实例，寻找没有配置zone的实例，适配原来没有配置zone的情况
for (ServiceInstance serviceInstance : serviceInstances) {
    String instanceZone = getZone(serviceInstance);
    if (StringUtils.isBlank(instanceZone)) {
        filteredInstances.add(serviceInstance);
    }
}
return filteredInstances;
这样在所有cn节点宕机后，不会路由到us节点

3.新增自定义CustomRequestHeaderServiceInstanceListSupplier，参考ZonePreferenceServiceInstanceListSupplier实现
feign demo:
R<CustomUserEntity> getByEmail(@RequestParam("email") String email, @RequestHeader(SecurityConstants.FROM) String from, @RequestHeader("zone") String zone);
指定zone=cn，如果cn节点宕机，也不会路由到us节点
